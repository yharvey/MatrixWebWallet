<template>
  <div class="my-wallet card-width">
    <router-view></router-view>
  </div>
</template>

<script>

export default {
  name: 'MyWallet',
  mounted () {
  },
  data () {
    return {
    }
  }
}
</script>

<style scoped lang="less">
.my-wallet{
  margin: 0 auto;
}
</style>
