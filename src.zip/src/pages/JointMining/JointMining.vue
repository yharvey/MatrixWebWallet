<template>
  <keep-alive>
    <router-view />
  </keep-alive>
</template>

<script>
export default {
  name: 'jointMining',
  data () {
    return {
    }
  }
}
</script>

<style scoped lang="less">
</style>
