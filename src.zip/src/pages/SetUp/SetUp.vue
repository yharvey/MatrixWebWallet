<template>
  <div>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'Setup'
}
</script>

<style scoped lang="less">
</style>
