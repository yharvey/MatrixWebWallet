export const wallet = state => state.wallet
export const mnemonic = state => state.mnemonic
export const historyUrl = state => state.historyUrl
export const balance = state => state.balance
export const offline = state => state.offline
export const mode = state => state.mode
