const state = {
  wallet: null,
  historyUrl: null,
  beforeUrl: null,
  mnemonic: '',
  balance: null,
  offline: null,
  mode: true
}

export default state
