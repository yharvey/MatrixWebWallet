<template>
  <div class="demo align-center">
  </div>
</template>

<script>
export default {
  name: 'demo',
  data () {
    return {
    }
  },
  methods: {
  },
  components: {
  }
}
</script>

<style scoped lang="less">
  .demo {
  }
</style>
